public interface Observer {
    void updateGas();
    void updateBrake();
    void updateLiftbed();
    void updateLowerbed();
    void updateTurboOn();
    void updateTurboOff();
    void updateStartengine();
    void updateStopengine();
}
