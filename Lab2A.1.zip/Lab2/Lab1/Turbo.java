public interface Turbo {
    void turboOn();
    void turboOff();
}
