import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/*
* This class represents the Controller part in the MVC pattern.
* It's responsibilities is to listen to the View and responds in a appropriate manner by
* modifying the model state and the updating the view.
 */

public class CarController implements Observer{
    // member fields:

    // The delay (ms) corresponds to 20 updates a sec (hz)
    private final int delay = 50;
    // The timer is started with an listener (see below) that executes the statements
    // each step between delays.
    private Timer timer = new Timer(delay, new TimerListener());

    // The frame that represents this instance View of the MVC pattern
    CarView frame;
    // A list of cars, modify if needed
    ArrayList<Vehicle> cars = new ArrayList<>();

    //methods:

    public static void main(String[] args) {
        // Instance of this class
        CarController cc = new CarController();

        Car a = new Volvo240(Color.GRAY, 80, "Volvo240", 4);
        a.horizontal = 100;
        Car b = new Saab95(Color.GRAY, 200, "Saab95", 4);
        b.horizontal = 200;
        Vehicle c = new Scania(Color.GRAY, 200, "Scania", 4);
        c.horizontal = 300;
        Vehicle d = new CarTransport(Color.GRAY, 200, "Volvo240", 4);

        cc.cars.add(a);
        cc.cars.add(b);
        cc.cars.add(c);
        cc.cars.add(d);

        // Start a new view and send a reference of self
        cc.frame = new CarView("CarSim 1.0", cc);

        // Start the timer
        cc.timer.start();
    }

    @Override
    public void updateGas() {
        gas(frame.gasAmount);
    }

    @Override
    public void updateBrake() {
        brake(frame.gasAmount);
    }

    @Override
    public void updateLiftbed() {
        for(Vehicle v : cars){
            if(v instanceof Lift){
                ((Scania) v).tiltUp(frame.liftAmount);
            }
        }
    }

    @Override
    public void updateLowerbed() {
        for(Vehicle v : cars){
            if(v instanceof Lift){
                ((Scania) v).tiltDown(frame.liftAmount);
            }
        }
    }

    @Override
    public void updateTurboOn() {
        for(Vehicle v : cars){
            if(v instanceof Turbo){
                ((Saab95) v).turboOn();
            }

        }
    }

    @Override
    public void updateTurboOff() {
        for(Vehicle v : cars){
            if(v instanceof Turbo){
                ((Saab95) v).turboOff();
            }
        }
    }

    @Override
    public void updateStartengine() {
        startEngine();
    }

    @Override
    public void updateStopengine() {
        stopEngine();
    }

    /* Each step the TimerListener moves all the cars in the list and tells the
    * view to update its images. Change this method to your needs.
    * */
    private class TimerListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            for (Vehicle vehicle : cars) {
                changeDirection(vehicle);
                vehicle.move();
                int x = (int) Math.round(vehicle.getHorizontal());
                int y = (int) Math.round(vehicle.getVertical());
                /*for(Vehicle a : cars){
                    if(a.modelName.equals("Scania")){
                        System.out.println(((Scania) a).tiltAngle);
                    }
                }*/
                frame.drawPanel.moveit(x, y);
                // repaint() calls the paintComponent method of the panel
                frame.drawPanel.repaint();
            }
        }
    }

    // Calls the gas method for each car once
    void gas(int amount) {
        double gas = ((double) amount) / 100;
        for (Vehicle car : cars) {
            car.gas(gas);
        }
    }

    void brake(int amount){
        double brake = ((double) amount) / 100;
        for (Vehicle car : cars) {
            car.brake(brake);
        }
    }

    void stopEngine() {
        for (Vehicle car : cars) {
            car.stopEngine();
        }
    }

    void startEngine(){
        for (Vehicle car : cars){
            car.startEngine();
        }
    }

    private void changeDirection(Vehicle car) {
        if (car.horizontal > frame.drawPanel.getWidth() - 100 || car.horizontal < 0
                || car.vertical > frame.drawPanel.getHeight() - 60|| car.vertical < 0) {
            double currentSpeed = car.currentSpeed;
            car.stopEngine();
            car.turnLeft();
            car.turnLeft();
            car.startEngine();
            car.currentSpeed = currentSpeed;
            car.move();
        }
    }
}

