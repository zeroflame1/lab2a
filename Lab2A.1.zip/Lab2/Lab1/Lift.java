public interface Lift {
    void tiltDown(int amount);
    void tiltUp(int amount);
}
