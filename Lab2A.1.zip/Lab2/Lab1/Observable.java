public interface Observable {
    void notifyGas();
    void notifyBrake();
    void notifyLiftbed();
    void notifyLowerbed();
    void notifyTurboOn();
    void notifyTurboOff();
    void notifyStartengine();
    void notifyStopengine();
    void registerObserver(Observer o);
}
