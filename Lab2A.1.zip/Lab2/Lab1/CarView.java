import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * This class represents the full view of the MVC pattern of your car simulator.
 * It initializes with being center on the screen and attaching it's controller in it's state.
 * It communicates with the Controller by calling methods of it when an action fires of in
 * each of it's components.
 * TODO: Write more actionListeners and wire the rest of the buttons
 **/

public class CarView extends JFrame implements ActionListener,Observable{
    private static final int X = 800;
    private static final int Y = 800;

    // The controller member
    ArrayList<Observer> observer = new ArrayList<>();


    CarController carC;

    DrawPanel drawPanel;

    JPanel controlPanel = new JPanel();

    JPanel gasPanel = new JPanel();
    JSpinner gasSpinner = new JSpinner();
    int gasAmount = 0;
    JLabel gasLabel = new JLabel("Amount of gas");

    /////////////
    JPanel liftPanel = new JPanel();
    JSpinner liftSpinner = new JSpinner();
    int liftAmount = 0;
    JLabel liftLabel = new JLabel("Amount of lift");
    /////////////

    JButton gasButton = new JButton("Gas");
    JButton brakeButton = new JButton("Brake");
    JButton turboOnButton = new JButton("Saab Turbo on");
    JButton turboOffButton = new JButton("Saab Turbo off");
    JButton liftBedButton = new JButton("Scania Lift Bed");
    JButton lowerBedButton = new JButton("Lower Lift Bed");

    JButton startButton = new JButton("Start all cars");
    JButton stopButton = new JButton("Stop all cars");

    // Constructor
    public CarView(String framename, CarController cc){
        registerObserver(cc);
        this.carC = cc;
        initComponents(framename);
    }

    // Sets everything in place and fits everything
    // TODO: Take a good look and make sure you understand how these methods and components work
    private void initComponents(String title) {

        drawPanel = new DrawPanel(X, Y-240,carC.cars); //kanske fixa beroende till Draw.

        this.setTitle(title);
        this.setPreferredSize(new Dimension(X,Y));
        this.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));

        this.add(drawPanel);
        //////////////////

        SpinnerModel spinnerModel1 =
                new SpinnerNumberModel(0, //initial value
                        0, //min
                        100, //max
                        1);//step
        liftSpinner = new JSpinner(spinnerModel1);
        liftSpinner.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                liftAmount = (int) ((JSpinner)e.getSource()).getValue();
            }
        });

        liftPanel.setLayout(new BorderLayout());
        liftPanel.add(liftLabel, BorderLayout.PAGE_START);
        liftPanel.add(liftSpinner, BorderLayout.PAGE_END);

        this.add(liftPanel);

        //////////////// added this stuff
        SpinnerModel spinnerModel =
                new SpinnerNumberModel(0, //initial value
                        0, //min
                        100, //max
                        1);//step
        gasSpinner = new JSpinner(spinnerModel);
        gasSpinner.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                gasAmount = (int) ((JSpinner)e.getSource()).getValue();
            }
        });




        gasPanel.setLayout(new BorderLayout());
        gasPanel.add(gasLabel, BorderLayout.PAGE_START);
        gasPanel.add(gasSpinner, BorderLayout.PAGE_END);

        this.add(gasPanel);

        controlPanel.setLayout(new GridLayout(2,4));

        controlPanel.add(gasButton, 0);
        controlPanel.add(turboOnButton, 1);
        controlPanel.add(liftBedButton, 2);
        controlPanel.add(brakeButton, 3);
        controlPanel.add(turboOffButton, 4);
        controlPanel.add(lowerBedButton, 5);
        controlPanel.setPreferredSize(new Dimension((X/2)+4, 200));
        this.add(controlPanel);
        controlPanel.setBackground(Color.CYAN);


        startButton.setBackground(Color.green);
        startButton.setForeground(Color.black);
        startButton.setPreferredSize(new Dimension(X/5-51,200)); //(X/5-15) used to be
        this.add(startButton);


        stopButton.setBackground(Color.red);
        stopButton.setForeground(Color.black);
        stopButton.setPreferredSize(new Dimension(X/5-52,200)); //(X/5-15) used to be
        this.add(stopButton);

        // This actionListener is for the gas button only
        // TODO: Create more for each component as necessary
        gasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                notifyGas();
            }
        });
        brakeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                notifyBrake();
            }
        });
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                notifyStartengine();
            }
        });
        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                notifyStopengine();
            }
        });
        turboOnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                notifyTurboOn();
            }
        });
        turboOffButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                notifyTurboOff();
            }
        });
        liftBedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                notifyLiftbed();
            }
        });
        lowerBedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                notifyLowerbed();
            }
        });




        // Make the frame pack all it's components by respecting the sizes if possible.
        this.pack();

        // Get the computer screen resolution
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        // Center the frame
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
        // Make the frame visible
        this.setVisible(true);
        // Make sure the frame exits when "x" is pressed
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }

    @Override
    public void notifyGas() {
        for (Observer o : observer){
            o.updateGas();
        }
    }

    @Override
    public void notifyBrake() {
        for (Observer o : observer){
            o.updateBrake();
        }
    }

    @Override
    public void notifyLiftbed() {
        for (Observer o : observer){
            o.updateLiftbed();
        }
    }

    @Override
    public void notifyLowerbed() {
        for (Observer o : observer){
            o.updateLowerbed();
        }
    }

    @Override
    public void notifyTurboOn() {
        for (Observer o : observer){
            o.updateTurboOn();
        }
    }

    @Override
    public void notifyTurboOff() {
        for (Observer o : observer){
            o.updateTurboOff();
        }
    }

    @Override
    public void notifyStartengine() {
        for (Observer o : observer){
            o.updateStartengine();
        }
    }

    @Override
    public void notifyStopengine() {
        for (Observer o : observer){
            o.updateStopengine();
        }
    }

    @Override
    public void registerObserver(Observer o) {
        observer.add(o);
    }
}
