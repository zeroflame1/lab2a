public interface Observer {
}
