public interface Observable {
    void notifyGas();
    void notifyBrake();
}
